# **Trust Local Certificates**
## Description
A magisk Module that moves certificates from the user certificate store to the system store. As a sideeffect this will remove the annoying *Network may be monitored* warning. Great for adblocker that uses redirection method using their local certifcate.

Fork from Original Module - https://github.com/Magisk-Modules-Repo/movecert

## DISCLAMER
This module is provided as-is. Always use the stable version.

## Versioning
```
A.B.C - Version Code
AABBCC - Version Number

Major - A.0.0
Minor - A.B.0
Release Candidate - A.B.C
```
